Library for UBTech Aplha 1S servo
Dependency: https://github.com/Super169/espsoftwareserial.git dev branch